import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import pl.exam.SortTable;
import pl.logic.Main;

@SpringBootTest(classes = Main.class)
class SortTableTest {
    private SortTable sortTable;

    @BeforeEach
    public void init() {
        sortTable = new SortTable();
    }

    @Test
    void shouldSortTable(){
        int[] tab = {1,5,3,4,10};
        String numbers  = sortTable.sort(tab).toString();
        assertEquals(tab.toString(),numbers);
        assertEquals(tab[0],1);
        assertEquals(tab[4],10);
    }

}