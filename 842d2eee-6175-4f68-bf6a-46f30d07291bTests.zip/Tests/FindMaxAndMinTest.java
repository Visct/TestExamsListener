import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import pl.exam.FindMaxAndMin;
import pl.logic.Main;

import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest(classes = Main.class)
public class FindMaxAndMinTest {

    private FindMaxAndMin findMaxAndMin;

    @BeforeEach
    public void init() {
        findMaxAndMin = new FindMaxAndMin();
    }
    String[] names = {"Adam", "Ew", "Elżbieta", "Valdemar", "Koń", "Grzegorz", "Ewelina", "Robert", "Gabriel", "Robczysławina"};


    @Test
    public void shouldReturnRobczysławinaAsTheLongestName() {
        assertEquals("Robczysławina", findMaxAndMin.theLongestName(names));

    }

    @Test
    public void shouldReturnEwAsTheShortestName() {
        assertEquals("Ew", findMaxAndMin.theShortestName(names));

    }

    @Test
    public void shouldReturn3AsNumberOfWomanNames (){
        assertEquals(3, findMaxAndMin.numberOfWomenName(names));
    }

    @Test
    public void shouldReturn35asPercentageOfWoman (){

        assertEquals(35.0, findMaxAndMin.percentageOfWomenNames(names), 0.1);

    }

}