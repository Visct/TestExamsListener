package pl.kurs;

import java.util.Arrays;

public class SortTable {

//        1) napisz metodę która jako argument pobiera tablicę intów oraz ją sortuje


    public int[] sort(int[] table){
        Arrays.sort(table);
        return table;
    }

}
