package pl.kurs;

public class FindMaxAndMin {

    public String theLongestName(String[] names) {
        String theLongestName = names[0];
        for (String name : names) {
            if (name.length() > theLongestName.length()) {
                theLongestName = name;
            }
        }
        return theLongestName;
    }

    public String theShortestName(String[] names) {
        String theShortestName = names[0];
        for (String name : names) {
            if (name.length() < theShortestName.length()) {
                theShortestName = name;
            }
        }
        return theShortestName;
    }

    public int numberOfWomenName(String[] names) {
        int numberOfWomenName = 0;
        for (String name : names) {
            if (name.endsWith("a")) {
                numberOfWomenName++;
            }
        }
        return numberOfWomenName;
    }

    public double percentageOfWomenNames(String[] names) {
        int numberOfWomenName = 0;
        for (String name : names) {
            if (name.endsWith("a")) {
                numberOfWomenName++;
            }
        }

        return (numberOfWomenName *100) /names.length;
    }
}
